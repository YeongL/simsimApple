package com.example.sampleapplication_001;

import static android.widget.Toast.makeText;

import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Objects;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private FrameLayout dragObjectL;
    private FrameLayout dragObjectO;
    private FrameLayout dragObjectG;
    private FrameLayout dragObjectI;
    private FrameLayout dragObjectN;

    private FrameLayout dropObjectL;
    private FrameLayout dropObjectO;
    private FrameLayout dropObjectG;
    private FrameLayout dropObjectI;
    private FrameLayout dropObjectN;

    private RelativeLayout dropMain;

    private LinearLayout dropArea;
    private ImageButton loginButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //드래그할 객체 참조
        dragObjectL = findViewById(R.id.layoutL1);
        dragObjectO = findViewById(R.id.layoutO1);
        dragObjectG = findViewById(R.id.layoutG1);
        dragObjectI = findViewById(R.id.layoutI1);
        dragObjectN = findViewById(R.id.layoutN1);



        //드롭할 객체 참조
        dropObjectL = findViewById(R.id.layoutL);
        dropObjectO = findViewById(R.id.layoutO);
        dropObjectG = findViewById(R.id.layoutG);
        dropObjectI = findViewById(R.id.layoutI);
        dropObjectN = findViewById(R.id.layoutN);

        dropArea = findViewById(R.id.layoutlogin);

        dropMain = findViewById(R.id.main);

        //로그인 버튼 선언
        loginButton = findViewById(R.id.loginButton);



        //드래그할 객체 위치 랜덤
        setInitialPosition(dragObjectL);
        setInitialPosition(dragObjectO);
        setInitialPosition(dragObjectG);
        setInitialPosition(dragObjectI);
        setInitialPosition(dragObjectN);

        //드래그할 객체에 대한 공통 터치 리스너 설정
        setDragListener(dragObjectL);
        setDragListener(dragObjectO);
        setDragListener(dragObjectG);
        setDragListener(dragObjectI);
        setDragListener(dragObjectN);


        //전체 화면에 대해 드래그 이벤트 처리하기 위해 ondraglistener 추가
        dropMain.setOnDragListener(new View.OnDragListener() {
            @Override
            public boolean onDrag(View v, DragEvent event) {

                Log.d("drag&drop", "드래그 한다 까진 알았음");
                switch (event.getAction()){
                    case DragEvent.ACTION_DRAG_STARTED:
                        // 드래그 시작 시 처리
                        break;
                    case DragEvent.ACTION_DRAG_ENTERED:
                        // 드래그된 객체가 영역에 들어오면 색상 변경
                        Log.d("drag&drop", "영역 안에 들어옴");
                        break;

                    case DragEvent.ACTION_DRAG_EXITED:
                        // 드래그된 객체가 영역에서 나가면 색상 복구
                        Log.d("drag&drop", "영역 밖으로 나감");
                        break;

                    case DragEvent.ACTION_DROP:
                        // 드래그된 객체가 실제로 드롭되면
                        Log.d("drag&drop", "드롭한것도 알았음");
                        FrameLayout draggedFrame = (FrameLayout) event.getLocalState(); // 드래그된 뷰

                        if (draggedFrame != null) {
                            float x = event.getX(); // 드롭된 위치의 X 좌표
                            float y = event.getY(); // 드롭된 위치의 Y 좌표

                            Log.d("drag&drop", "드래그 뷰가 NULL은 아님");

                            // 드래그된 뷰가 RelativeLayout의 자식인지 확인
                            if (draggedFrame.getLayoutParams() instanceof RelativeLayout.LayoutParams) {
                                Log.d("drag&drop", "relative layout 자식인거까진 알았음");
                                RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) draggedFrame.getLayoutParams();

                                // 드롭된 위치에 객체 배치
                                layoutParams.leftMargin = (int) (x - draggedFrame.getWidth() / 2);  // 뷰의 중심을 드롭 위치로
                                layoutParams.topMargin = (int) (y - draggedFrame.getHeight() / 2);

                                // 새 위치로 설정된 레이아웃 파라미터를 적용
                                draggedFrame.setLayoutParams(layoutParams);

                            } else {
                                Log.d("drag&drop", "relative layout 자식 인지 못해서 안됨");
                            }

                        } else {
                            Log.d("drag&drop", "드래그 뷰가 NULL임");
                        }
                        

                        Toast.makeText(MainActivity.this, "드롭 성공!", Toast.LENGTH_SHORT).show();
                        break;

                    case DragEvent.ACTION_DRAG_ENDED:
                        Log.d("drag&drop", "드래그가 종료됨");
                        // 드래그가 종료되면 (취소된 경우) 아무 것도 하지 않습니다.
                        break;


                }
                return true;


            }
        });


        //드롭할 객체에 대한 공통 드래그 리스너 설정
        setDropListener(dropObjectL);
        setDropListener(dropObjectO);
        setDropListener(dropObjectG);
        setDropListener(dropObjectI);
        setDropListener(dropObjectN);


        



    }

    private void setDragListener(FrameLayout dragFrame) {
        dragFrame.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    // 드래그 시작
                    View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(dragFrame);
                    dragFrame.startDragAndDrop(null, shadowBuilder, dragFrame, 0);
                    return true;
                }
                return false;
            }
        });
    }


    private void setDropListener(FrameLayout dropFrame) {
        dropFrame.setOnDragListener(new View.OnDragListener() {
            @Override
            public boolean onDrag(View v, DragEvent event) {


                switch (event.getAction()) {
                    case DragEvent.ACTION_DRAG_STARTED:
                        // 드래그 시작 시 처리
                        break;

                    case DragEvent.ACTION_DRAG_ENTERED:
                        // 드래그 객체가 dropFrame에 들어갈 때 배경색 변경
                        dropFrame.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));

                        break;

                    case DragEvent.ACTION_DRAG_EXITED:
                        // 드래그 객체가 dropFrame에서 나갈 때 배경색 원래대로 복원
                        dropFrame.setBackgroundColor(getResources().getColor(android.R.color.white));

                        break;

                    case DragEvent.ACTION_DROP:
                        // 드롭 후 색상 변경
                        View draggedFrame = (View) event.getLocalState(); // 드래그된 뷰
                        Log.d("TargetFrame","타겟 프레임에 드롭");
                        if (draggedFrame != null) {
                            float x = event.getX();
                            float y = event.getY();

                            // 드롭 영역의 절대 위치 계산
                            int[] dropLocation = new int[2];
                            v.getLocationOnScreen(dropLocation);  // 드롭 대상의 절대 위치 구하기

                            // 드래그된 뷰의 새로운 위치 계산
                            float absoluteX = dropLocation[0] + x - draggedFrame.getWidth() / 2;
                            float absoluteY = dropLocation[1] + y - draggedFrame.getHeight() / 2;

                            // 드래그된 뷰의 새로운 위치 설정
                            draggedFrame.setX(absoluteX);
                            draggedFrame.setY(absoluteY);

                            Log.d("TargetFrame", "위치 설정 할거임");
                        } else {
                            Log.d("TargetFrame", "드래그 뷰가 NULL임");
                        }
                        if (Objects.equals(getResources().getResourceEntryName(draggedFrame.getId()), getResources().getResourceEntryName(dropFrame.getId()) + "1"))
                        {
                            Log.d("TargetFrame","정확한 타겟에 드롭함");

                            dropFrame.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));
                            checkIfButtonIsReady();
                        } else {
                            dropFrame.setBackgroundColor(getResources().getColor(android.R.color.white));
                            Log.d("TargetFrame","알맞은 타겟이 아님..");
                        }




                        Toast.makeText(MainActivity.this, "프레임에 드래그 완료", Toast.LENGTH_SHORT).show();


                        break;

                    case DragEvent.ACTION_DRAG_ENDED:
                        // 드래그가 끝난 후 처리
                        break;
                }
                return true;
            }
        });
    }

    private void checkIfButtonIsReady(){
        Log.d("LoginButtonVisible","로그인 버튼 활성화 체크 부분");
        boolean allObjectHasLetter = isObjectHasLetter(dropObjectL,getResources().getColor(android.R.color.darker_gray)) &&
                isObjectHasLetter(dropObjectO,getResources().getColor(android.R.color.darker_gray)) &&
                isObjectHasLetter(dropObjectG,getResources().getColor(android.R.color.darker_gray)) &&
                isObjectHasLetter(dropObjectI,getResources().getColor(android.R.color.darker_gray)) &&
                isObjectHasLetter(dropObjectN,getResources().getColor(android.R.color.darker_gray));
        if (allObjectHasLetter)
        {
            loginButton.setVisibility(View.VISIBLE);
            Log.d("LoginButtonVisible","로그인 버튼 활성화");

        } else {
            loginButton.setVisibility(View.INVISIBLE);
            Log.d("LoginButtonVisible","로그인 버튼 활성화 실패");

        }

    }

    private boolean isObjectHasLetter(FrameLayout object, int grayColor){



        if (object.getBackground() != null && object.getBackground() instanceof ColorDrawable) {
            int color = ((ColorDrawable) object.getBackground()).getColor();

            Log.d("color check", getResources().getResourceEntryName(object.getId()) + " 색상체크");
            if(color == grayColor)
            {
                Log.d("color check", getResources().getResourceEntryName(object.getId()) + " 색상체크 성공");
                return true;
            }

        }
        Log.d("color check", getResources().getResourceEntryName(object.getId()) +" 색상체크 실패");
        return  false;

    }

    // FrameLayout의 초기 위치 설정
    private void setInitialPosition(FrameLayout draggableFrame) {
        // RelativeLayout.LayoutParams 생성
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT
        );

        // 초기 위치를 설정 (랜덤)
        Random rd = new Random();
        params.leftMargin = rd.nextInt(1000);  // 왼쪽 여백 (1000px 이하 숫자)
        params.topMargin = rd.nextInt(1900);   // 위쪽 여백 (1900px 이하 숫자)

        // LayoutParams를 FrameLayout에 적용
        draggableFrame.setLayoutParams(params);
    }


}